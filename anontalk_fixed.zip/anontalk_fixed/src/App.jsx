import React, { useState } from "react";

function PaymentModal({ onClose }) {
  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
      <div className="bg-white p-6 rounded-2xl shadow-xl w-96 text-center">
        <h2 className="text-xl font-bold mb-4">Mock Payment</h2>
        <p className="mb-4">This is a demo checkout flow (Stripe/Paystack mock).</p>
        <button
          onClick={onClose}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition"
        >
          Close
        </button>
      </div>
    </div>
  );
}

export default function App() {
  const [showPayment, setShowPayment] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <header className="bg-white shadow-md p-4 flex justify-between items-center">
        <h1 className="text-2xl font-bold text-blue-600">AnonTalk</h1>
        <nav className="space-x-4">
          <a href="#about" className="hover:underline">About</a>
          <a href="#features" className="hover:underline">Features</a>
          <a href="#pricing" className="hover:underline">Pricing</a>
        </nav>
      </header>

      {/* Hero */}
      <section className="flex-1 flex flex-col items-center justify-center text-center px-4 py-16">
        <h2 className="text-4xl font-bold mb-4">Talk to Someone, Anonymously</h2>
        <p className="text-lg mb-6 max-w-2xl">
          We provide a safe and private space where you can talk to analysts and consultants anonymously. 
          Sometimes, you just need someone to listen.
        </p>
        <button
          onClick={() => setShowPayment(true)}
          className="bg-blue-600 text-white px-6 py-3 rounded-xl hover:bg-blue-700 transition"
        >
          Start a Session
        </button>
      </section>

      {/* Features */}
      <section id="features" className="bg-white py-12 px-6">
        <h3 className="text-2xl font-bold text-center mb-8">Why Choose Us?</h3>
        <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          <div className="p-6 bg-gray-100 rounded-2xl shadow">
            <h4 className="font-semibold mb-2">Anonymous</h4>
            <p>Your identity remains private while you share openly.</p>
          </div>
          <div className="p-6 bg-gray-100 rounded-2xl shadow">
            <h4 className="font-semibold mb-2">Affordable</h4>
            <p>Low-cost sessions with flexible payment options.</p>
          </div>
          <div className="p-6 bg-gray-100 rounded-2xl shadow">
            <h4 className="font-semibold mb-2">Professional</h4>
            <p>Get support from real analysts and consultants.</p>
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="py-12 px-6 bg-gray-50">
        <h3 className="text-2xl font-bold text-center mb-8">Pricing</h3>
        <div className="max-w-md mx-auto bg-white p-6 rounded-2xl shadow text-center">
          <p className="text-lg mb-2">One Session</p>
          <p className="text-3xl font-bold mb-4">$5</p>
          <button
            onClick={() => setShowPayment(true)}
            className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition"
          >
            Pay & Start
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white shadow-inner p-4 text-center">
        <p className="text-gray-600 text-sm">
          © {new Date().getFullYear()} AnonTalk. All rights reserved.
        </p>
      </footer>

      {showPayment && <PaymentModal onClose={() => setShowPayment(false)} />}
    </div>
  );
}
