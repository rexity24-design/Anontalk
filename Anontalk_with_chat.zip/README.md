# Anontalk

Anonymous chat prototype website with Home and Chat page.

## How to Deploy

1. Extract this project.
2. Open GitHub Desktop → Add folder → Commit & Push.
3. Go to [Vercel](https://vercel.com) → Import GitHub repo.
4. In **Settings → Build & Development**:
   - Framework: Vite
   - Build command: npm run build
   - Output directory: dist
5. Deploy 🚀

