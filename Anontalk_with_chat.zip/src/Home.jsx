import React from "react";
import { Link } from "react-router-dom";

export default function Home() {
  return (
    <div style={{ textAlign: "center", padding: "2rem" }}>
      <h1>Welcome to Anontalk</h1>
      <p>Your safe and anonymous place to talk.</p>
      <Link to="/chat">
        <button style={{ padding: "10px 20px", marginTop: "20px" }}>
          Enter Chat
        </button>
      </Link>
    </div>
  );
}
