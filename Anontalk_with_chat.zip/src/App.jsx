import React from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Home from "./Home";
import Chat from "./Chat";

export default function App() {
  return (
    <Router>
      <nav style={{ padding: "1rem", background: "#f4f4f4" }}>
        <Link to="/" style={{ marginRight: "1rem" }}>Home</Link>
        <Link to="/chat">Chat</Link>
      </nav>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/chat" element={<Chat />} />
      </Routes>
    </Router>
  );
}
