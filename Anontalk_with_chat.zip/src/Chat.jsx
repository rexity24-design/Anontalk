import React, { useState } from "react";

export default function Chat() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");

  const sendMessage = () => {
    if (input.trim() === "") return;
    setMessages([...messages, { text: input }]);
    setInput("");
  };

  return (
    <div style={{ padding: "2rem" }}>
      <h2>Anonymous Chat Room</h2>
      <div style={{
        border: "1px solid #ccc",
        padding: "1rem",
        height: "300px",
        overflowY: "auto",
        marginBottom: "1rem"
      }}>
        {messages.length === 0 ? (
          <p>No messages yet. Start chatting!</p>
        ) : (
          messages.map((m, i) => <p key={i}>{m.text}</p>)
        )}
      </div>
      <input
        value={input}
        onChange={(e) => setInput(e.target.value)}
        placeholder="Type your message..."
        style={{ padding: "10px", width: "70%" }}
      />
      <button onClick={sendMessage} style={{ padding: "10px 20px", marginLeft: "10px" }}>
        Send
      </button>
    </div>
  );
}
