# AnonTalk (Prototype)
Static React prototype for the anonymous chat site. Built for Vite. Uses Tailwind CDN for styling.
